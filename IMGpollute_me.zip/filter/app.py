from flask import *
import os
import base64
import waf
app = Flask(__name__)
app.secret_key = os.urandom(64)

users_db = {
}

@app.route("/", methods=['GET', 'POST'])
def index():
    if "username" in session:
        result = None
        if request.method == "POST":
            text = request.form.get("text")
            action = request.form.get("action")
            if text and action:
                if action == "encode":
                    encoded_text = base64.b64encode(text.encode()).decode()
                    result = f"编码结果：{encoded_text}"
                elif action == "decode":
                    try:
                        decoded_text = base64.b64decode(text).decode()
                        if decoded_text.isprintable():
                            result = f"解码结果：{decoded_text}"
                    except Exception as e:
                        result = "解码失败，请检查输入。"
            else:
                result = "请输入文本并选择操作。"
        #return render_template("index.html", username=session.get("username"), result=result)
        return render_template("index.html", username=session["username"], result=result)
    return render_template("index.html", username=None, result=None)



@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if waf.waf(username) == False:
            return "用户名中含有非法字符。"
        if username and password and users_db.get(username) and users_db[username]["password"] == password:
            session["username"] = username

            template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>欢迎</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h2 {
            color: #333333;
            margin-bottom: 10px;
        }
        p {
            color: #777777;
        }
    </style>
    <script>
        window.onload = function() {
            setTimeout(function() {
                window.location.href = "{{ url_for('index') }}";
            }, 3000);
        };
    </script>
</head>
<body>
    <div class="container">
        <h2>欢迎回来，{{ """+username+""" }}！</h2>
        <p>将在3秒后跳转到首页...</p>
    </div>
</body>
</html>
                """

            return render_template_string(template)

        else:
            return "登录失败，请检查用户名和密码。"
        return redirect(url_for("index"))
    return render_template("login.html")
@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username and password:
            if username not in users_db:
                users_db[username] = {"username": username, "password": password}
                print(users_db)
                return redirect(url_for("login"))
            else:
                return "用户名已被占用。"
        else:
            return "用户名和密码不能为空。"
    return render_template("register.html")


@app.route("/logout")
def logout():
    session.pop("username", None)
    return redirect(url_for("index"))


if __name__ == '__main__':
    file = open("/flag", "r")
    FFFFlag = file.read()
    file.close()
    FFFFlag = bytes([a ^ b for a, b in zip(FFFFlag.encode(), app.secret_key)])
    os.remove("/flag")
    app.run(host="0.0.0.0",debug=True)
